# ITechru Customer Management — prototype + secure backend starter

## What's included
- `index.html`: interactive admin dashboard prototype and customer-site request-form concept.
- `supabase/schema.sql`: Postgres tables, status enum, indexes, and row-level security policies.
- `supabase/functions/new-repair-request/index.ts`: server-side public intake endpoint that validates fields, stores the request, and sends an email notification via Resend when configured.

## Important limits
The HTML is a **local prototype**, not a deployed production system. Its demo records are stored in this browser's `localStorage`; they do not sync across devices and are not protected as customer records. The sample customers are fictional. Do not enter real customer data into the prototype. It does not send email and does not process payments.

The SQL and Edge Function are a production-oriented starter, not an already-connected backend. They must be deployed/configured and the dashboard frontend must be wired to Supabase Auth + the database before collecting real customer information.

## Suggested production setup
1. Create a Supabase project.
2. Review and run `supabase/schema.sql` in the Supabase SQL Editor.
3. Create your admin user with Supabase Auth. Copy that user's UUID and insert it into `public.admin_users` using the commented SQL at the bottom of `schema.sql`. Only grant admin membership to accounts you control.
4. Deploy the Edge Function:
   `supabase functions deploy new-repair-request`
5. Configure Edge Function secrets:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY` (server-side secret only; never put in browser HTML)
   - `RESEND_API_KEY`
   - `ADMIN_NOTIFICATION_EMAIL`
   - `MAIL_FROM` (a sender/domain verified in Resend)
   - `ALLOWED_ORIGIN` (your exact website origin; do not leave the placeholder)
6. Add rate limiting and CAPTCHA/bot protection to the public request endpoint before production use. Configure CORS to the exact production origin.
7. Connect the customer form to the Edge Function URL. Connect the private admin dashboard to Supabase using the public anon/publishable key and Supabase Auth. RLS must remain enabled; never expose the service role key.
8. Add tests for login, anonymous access denial, admin access, form validation, export, email failure, and mobile layouts before launch.

## Security model
- Public customers submit to one server-side Edge Function. It validates input and uses a server-only service role key to insert a request.
- Anonymous users receive no direct table policies.
- Authenticated admins must be explicitly listed in `admin_users`; row-level security protects requests and notes.
- Internal notes are in a separate table from customer-facing request details.
- Store estimates and payments as integer cents. Do not store credit-card numbers, CVV, bank credentials, or payment processor secrets in this system.
- Email notifications contain customer-provided content. Keep the notification inbox private and consider sending only a brief alert plus reference ID rather than full issue details.

## Email notification
The Edge Function uses Resend's email API. You need a Resend account and verified sender. Email delivery failures are logged; a saved request is still accepted so a transient email outage does not lose customer intake.

## Status tracking, estimates, payments, notes and exports
The prototype demonstrates these interactions. For production, use the authenticated Supabase client for admin reads/updates and note creation; the included RLS policies enforce admin membership. Add an audit log if you need a record of every status or payment edit. “Payments” here means manually recording amounts paid, not charging cards.

## Deployment
This bundle is not hosted. Deploy the public site on a static host (for example, your existing hosting provider) and deploy the backend separately in Supabase. Do not publish the dashboard publicly without authentication.
