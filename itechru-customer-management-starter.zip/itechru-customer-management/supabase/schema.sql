-- ITechru production database schema for Supabase Postgres
-- Apply using Supabase SQL Editor in a NEW project after reviewing this file.
create extension if not exists pgcrypto;

create type public.repair_status as enum (
  'New Request','Contacted','Diagnosing','Waiting for Parts',
  'In Progress','Completed','Cancelled'
);

create table public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admin_users enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer
set search_path = public
as $$
  select exists (select 1 from public.admin_users a where a.user_id = auth.uid());
$$;

create table public.repair_requests (
  id uuid primary key default gen_random_uuid(),
  reference text not null unique,
  customer_name text not null check (length(customer_name) between 1 and 160),
  customer_email text not null check (length(customer_email) <= 320),
  customer_phone text,
  device text not null,
  service text not null,
  preferred_support text,
  problem_description text not null check (length(problem_description) <= 10000),
  status public.repair_status not null default 'New Request',
  estimate_cents integer not null default 0 check (estimate_cents >= 0),
  paid_cents integer not null default 0 check (paid_cents >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index repair_requests_created_at_idx on public.repair_requests(created_at desc);
create index repair_requests_email_idx on public.repair_requests(lower(customer_email));

create table public.repair_notes (
  id uuid primary key default gen_random_uuid(),
  repair_id uuid not null references public.repair_requests(id) on delete cascade,
  note text not null check (length(note) between 1 and 10000),
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now()
);
create index repair_notes_repair_id_idx on public.repair_notes(repair_id, created_at desc);

alter table public.repair_requests enable row level security;
alter table public.repair_notes enable row level security;

-- No anonymous table access. Public form inserts only through the Edge Function
-- using the server-side service role key; dashboard access requires admin membership.
create policy "admins read requests" on public.repair_requests for select to authenticated using (public.is_admin());
create policy "admins update requests" on public.repair_requests for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admins delete requests" on public.repair_requests for delete to authenticated using (public.is_admin());
create policy "admins read notes" on public.repair_notes for select to authenticated using (public.is_admin());
create policy "admins add notes" on public.repair_notes for insert to authenticated with check (public.is_admin() and created_by = auth.uid());
create policy "admins update notes" on public.repair_notes for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "admins delete notes" on public.repair_notes for delete to authenticated using (public.is_admin());

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;
create trigger repair_requests_updated_at before update on public.repair_requests
for each row execute function public.set_updated_at();

-- Add your authenticated admin account only after signing up through Supabase Auth:
-- insert into public.admin_users(user_id) values ('YOUR_AUTH_USER_UUID');
