// Admin writes should normally be made directly with the authenticated Supabase client,
// protected by the repair_requests / repair_notes RLS policies in schema.sql.
// This file documents the intended server-side validation contract for any future
// privileged admin Edge Function. Never accept a user_id or admin flag from request JSON.
