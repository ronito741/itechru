// Supabase Edge Function: public customer intake + email notification.
// Configure secrets: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, RESEND_API_KEY,
// ADMIN_NOTIFICATION_EMAIL, MAIL_FROM (verified sender in Resend).
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") ?? "https://YOUR-DOMAIN.example",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const body = await req.json();
    const name = String(body.name ?? "").trim();
    const email = String(body.email ?? "").trim().toLowerCase();
    const phone = String(body.phone ?? "").trim();
    const device = String(body.device ?? "").trim();
    const service = String(body.service ?? "").trim();
    const support = String(body.support ?? "").trim();
    const details = String(body.details ?? "").trim();

    if (!name || name.length > 160 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 320 ||
        !device || !service || !details || details.length > 10000) {
      return json({ error: "Please check the required fields and try again." }, 400);
    }

    // Add rate limiting / CAPTCHA at the edge before exposing this endpoint publicly.
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { persistSession: false, autoRefreshToken: false } },
    );

    const reference = `IT-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    const { data, error } = await supabase.from("repair_requests").insert({
      reference, customer_name: name, customer_email: email, customer_phone: phone,
      device, service, preferred_support: support, problem_description: details,
      status: "New Request", estimate_cents: 0, paid_cents: 0,
    }).select("id, reference, customer_name, customer_email, device, service, problem_description, created_at").single();

    if (error) {
      console.error("repair request insert failed", error.message);
      return json({ error: "We could not save your request right now. Please try again later." }, 500);
    }

    // Notification failure must not undo a successfully stored customer request.
    const resendKey = Deno.env.get("RESEND_API_KEY");
    const to = Deno.env.get("ADMIN_NOTIFICATION_EMAIL");
    const from = Deno.env.get("MAIL_FROM");
    if (resendKey && to && from) {
      const mail = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Authorization": `Bearer ${resendKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from, to: [to], subject: `New ITechru repair request ${data.reference}`,
          text: `New customer request received.\n\nReference: ${data.reference}\nName: ${name}\nEmail: ${email}\nDevice: ${device}\nService: ${service}\nPreferred support: ${support}\n\nProblem:\n${details}\n\nOpen your private ITechru admin dashboard to review it.`,
        }),
      });
      if (!mail.ok) console.error("notification email failed", mail.status, await mail.text());
    } else {
      console.warn("Email notification secrets are not configured.");
    }

    return json({ ok: true, reference: data.reference, message: "Your repair request was received." }, 201);
  } catch (err) {
    console.error("unexpected intake error", err);
    return json({ error: "Unexpected server error." }, 500);
  }
});
